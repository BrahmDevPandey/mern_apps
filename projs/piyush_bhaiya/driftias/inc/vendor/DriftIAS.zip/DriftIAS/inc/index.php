<?php
header('location:student_dashboard_index.php');
?>